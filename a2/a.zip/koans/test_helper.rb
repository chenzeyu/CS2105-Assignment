require 'test/unit'

def __
  "FILL ME IN"
end

EdgeCase = Test::Unit
