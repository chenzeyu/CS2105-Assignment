require File.expand_path(File.dirname(__FILE__) + '/edgecase')
